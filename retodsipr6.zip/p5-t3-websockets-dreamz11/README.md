Simple App Chat
===================


Hey! Here is my first application using node.js (express) and socket.io. It is a simple **chat app**. 

You can read the medium blog post to follow the explanations : https://medium.com/@noufel.gouirhate/build-a-simple-chat-app-with-node-js-and-socket-io-ea716c093088

# Run App

1) Download Repo

2) Install [Node.JS](https://nodejs.org/en/) 

3) Install Dependencies - NPM Install


# Run NPM START 

and browse https://localhost:port
