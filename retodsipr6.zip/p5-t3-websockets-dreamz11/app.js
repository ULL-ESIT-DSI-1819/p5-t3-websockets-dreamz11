const express = require('express')
const app = express()
var ip= require('ip')

//set the template engine ejs
app.set('view engine', 'ejs')

//middlewares
app.use(express.static('public'))


//routes
app.get('/', (req, res) => {
	res.render('index')
})

//Listen on port 3000

server = app.listen(8080, function()  {

    var host = server.address().address
    var port = server.address().port
    
    console.log('Example app listening at http://%s:%s', host, port)
    
    })


var rooms = ['Practicas','Ocio'];


//socket.io instantiation
const io = require("socket.io")(server)


//listen on every connection
io.on('connection', (socket) => {
	console.log('New user connected')

	//default username
	socket.username = "Anonymous"

    socket.room = 'Practicas';
    socket.join('Practicas');
    socket.emit('updatechat', 'SERVER', 'you have connected to Practicas');
    socket.broadcast.to('Practicas').emit('updatechat', 'SERVER', socket.username + ' has connected to this room');
    socket.emit('updaterooms', rooms, 'Practicas');
    //listen on change_username
    socket.on('change_username', (data) => {
        socket.username = data.username
    })

    //listen on new_message
	socket.on('sendchat', function (data) {
		// we tell the client to execute 'updatechat' with 2 parameters
		io.sockets.in(socket.room).emit('updatechat', socket.username, data);
	});

    socket.on('switchRoom', function(newroom){
		socket.leave(socket.room);
		socket.join(newroom);
		socket.emit('updatechat', 'SERVER', 'you have connected to '+ newroom);
		// sent message to OLD room
		socket.broadcast.to(socket.room).emit('updatechat', 'SERVER', socket.username+' has left this room');
		// update socket session room title
		socket.room = newroom;
		socket.broadcast.to(newroom).emit('updatechat', 'SERVER', socket.username+' has joined this room');
		socket.emit('updaterooms', rooms, newroom);
    });
    

})
